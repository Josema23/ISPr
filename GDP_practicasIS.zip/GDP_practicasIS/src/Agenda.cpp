/*
 * Agenda.cpp
 *
 *  Created on: 03/12/2014
 *      Author: i32goora
 */

#include <iostream>
#include <list>
#include <cstdlib>
#include <fstream>

#include "Agenda.h"
#include "Contacto.h"
#include "Funciones.h"


using namespace std;

namespace consulta {

	Agenda::Agenda() {
		// TODO Auto-generated constructor stub

	}

	Agenda::~Agenda() {
		// TODO Auto-generated destructor stub
	}

	bool Agenda::insertarPaciente(const Contacto& c) {

		bool resultado;

		resultado=true;	//Partimos de que se hizo correctamente.

		try{

			listaContactos_.push_back(c);

		}
		catch(...){

			resultado=false;	//Error al insertar.

		}

		//Falta llamar al método para guardar la lista en el fichero de texto.
		//a.guardar();

		return resultado;
	}

	void Agenda::escribirFichero (string fichero){

		list <Contacto> :: iterator it;

		ofstream file;

		file.open( fichero.c_str() );

		for (it = listaContactos_.begin(); it != listaContactos_.end() ; it++){
			file << "Apellidos y nombre....: " << it->getApellido() << ", " << it->getNombre() << "\n";
			file << "DNI...................: " << it->getDni() << "\n";
			file << "Telefono fijo.........: " << it->getTlfFijo() << "\n";
			file << "Telefono movil........: " << it->getTlfMovil() << "\n";
			file << "Direccion postal......: " << it->getDireccionpostal() << "\n";
			file << "Email.................: " << it->getEmail() << "\n";
			file << "Observaciones.........: " << it->getObservaciones() << "\n";
			file << "Favorito..............: " << it->isFavorito() << "\n";
			file << "Frecuencia............: " << it->getFrecuente() << "\n";
		}

		file.close();
	}

	list <Contacto> Agenda::buscarPaciente (string apellido) {

		list <Contacto> auxC;
		list <Contacto> :: iterator it; //iterador lista

			//Busca contactos con el mismo apellido y los guarda en la lista
			for (it = listaContactos_.begin() ; it != listaContactos_.end() ; it++) {
				if (apellido ==  (*it).getApellido() ) {
					auxC.push_back(*it);
				}
			}

		return auxC;
	}

	bool Agenda::modificarPaciente(Contacto &c) {

			int opcion;
			string nombre;
			string apellido;
			string dni;
			string tlf_fijo;
			string tlf_movil;
			string direccionPostal;
			string email;
			string observaciones;
			string continuar;
			string acierto;

			do
			{
				do
				{
					cout << "\tOPCIONES" << endl;
					cout << "1. Nombre" << endl;
					cout << "2. Apellidos" << endl;
					cout << "3. DNI" << endl;
					cout << "4. Telefono fijo" << endl;
					cout << "5. Telefono movil" << endl;
					cout << "6. Direccion postal" << endl;
					cout << "7. Email" << endl;
					cout << "8. Observaciones" << endl;
					cout << "9. Favorito" << endl;
					cout << "10. Redes sociales" << endl;
					cout << "Escriba la opcion...: ";
					cin >> opcion;

				} while (opcion>10 || opcion<1);

				switch (opcion){

					case 1:
						cin.ignore();
						cout << "Escriba el nuevo nombre...:";
						getline (cin, nombre);

						c.setNombre(nombre);
					break;

					case 2:
						cin.ignore();
						cout << "Escriba el nuevo apellido...:";
						getline (cin, apellido);

						c.setApellido(apellido);
					break;

					case 3:
						cout << "Escriba el nuevo dni...:";
						cin >> dni;

						c.setDni(dni);
					break;

					case 4:
						cout << "Escriba el nuevo telefono fijo...:";
						cin >> tlf_fijo;

						c.setTlfFijo(tlf_fijo);
					break;

					case 5:
						cout << "Escriba el nuevo telefono movil...:";
						cin >> tlf_movil;

						c.setTlfMovil(tlf_movil);
					break;

					case 6:
						cout << "Escriba la nueva direccion postal...:";
						cin >> direccionPostal;

						c.setDireccionpostal(direccionPostal);
					break;

					case 7:
						cout << "Escriba el nuevo email...:";
						cin >> email;

						c.setEmail(email);
					break;

					case 8:
						cin.ignore();
						cout << "Escriba la nueva observacion...:";
						getline(cin, observaciones);

						c.setObservaciones(observaciones);
					break;

					case 9:
						cout << "Seleccione como favorito(S/N)...:";
						cin >> acierto;

						if (acierto=="S" || acierto=="s"){
							c.setFavorito(true);
						} else {
							c.setFavorito(false);
						}

					break;

					case 10:

						cout << "HAY QUE ACLARAR";

					break;
				}

				cout << "Desea hacer otra modificacion...: ";
				cin >> continuar;

			}while (continuar=="S" || continuar=="s");

			return true;
		}

	bool Agenda::borrarPaciente(string dni) {

		list <Contacto> :: iterator it;

		for (it = listaContactos_.begin() ; it != listaContactos_.end() ; it++) {
			if (dni == (*it).getDni() ) {
				listaContactos_.erase(it);
				return true;
			}
		}

		return false;
	}

	bool Agenda::listadoPaciente() {

		//TODO: Esta opción debe recibir el formato y nombre de fichero, para generar el listado.





		ordenarLista();

		return true;

	}

	bool Agenda::restaurarCopiaSeguridad() {

			string nombreCopia="copia.txt";
			string fichOriginal="Agenda.txt";
			string correcto;
			//char *leidos;
			const int size=1024;

			//Falta la ruta que no tendo ni idea

			cout << "El nombre del fichero de copia es ' " << nombreCopia << " '\n";
			cout << "Desea cambier el nombre de la copia? (S/N)..: ";
			cin >> correcto;

			if (correcto=="S" || correcto=="s"){

				cout << "Nuevo nombre..: ";
				cin >> nombreCopia;

			}

			nombreCopia+=".txt";

			ifstream file( fichOriginal.c_str() );
			ofstream copiaFile ( nombreCopia.c_str() );


			if (!file){
				cout << "Error en la apertura" << endl;
				return false;

			} else {

				char * buffer = new char [size];

				//leidos=file.read (buffer,size);

				file.read (buffer,size);

				//while (atoi(leidos)>0){
				while (file){

					copiaFile.write (buffer,size);
					//leidos=file.read (buffer,size);

					file.read (buffer,size);

				}

				file.close();
				copiaFile.close();

				delete[] buffer;

				return true;
			}

	}

	bool Agenda::copiaSeguridad() {

			string nombreCopia="copia";
			string fichOriginal="Agenda.txt";
			string correcto;
			string ruta="/copiaseg";
			//char *leidos;
			const int size=1024;



			cout << "El nombre del fichero de copia es ' " << nombreCopia << " '\n";
			cout << "Desea cambiar el nombre de la copia? (S/N)..: ";
			cin >> correcto;

			if (correcto=="S" || correcto=="s"){

				cout << "Nuevo nombre..: ";
				cin >> nombreCopia;

			}

			nombreCopia+=".txt";

			ifstream file( fichOriginal.c_str() );

			ofstream copiaFile ( (ruta+nombreCopia).c_str() );


			if (!file){
				cout << "Error en la apertura" << endl;
				return false;

			} else {

				char * buffer = new char [size];

				//leidos=file.read (buffer,size);

				file.read (buffer,size);

				//while (atoi(leidos)>0){
				while (file){

					copiaFile.write (buffer,size);
					//leidos=file.read (buffer,size);

					file.read (buffer,size);

				}

				file.close();
				copiaFile.close();

				delete[] buffer;

				return true;
			}

	}

/*
	bool Agenda::comparacion (const Contacto &Primero,const Contacto &Segundo) {

		if ( ( Primero.getApellido() ).compare( Segundo.getApellido() ) < 0 ){
			return true;
		} else{
			return false;
		}

	}
*/

	void Agenda::ordenarLista () {

		//listaContactos_.sort(comparacion);
		listaContactos_.sort(comparacion);

	}

	void Agenda::masFrecuentes(string dni) {

		list <Contacto> :: iterator it;

		for (it = listaContactos_.begin() ; it != listaContactos_.end() ; it++) {
			if (dni == (*it).getDni() ) {
				(*it).setFrecuente( (*it).getFrecuente()+1 );
			}
		}

	}


} /* namespace consulta */
