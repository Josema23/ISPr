/*
 * Menu.cpp
 *
 *  Created on: 03/12/2014
 *      Author: i32goora
 */

#include <iostream>
#include <cstdlib>
#include <list>

#include "Agenda.h"
#include "Contacto.h"
#include "Funciones.h"	//Funciones auxiliares.

using namespace std;
using namespace consulta;


int main() {

	Agenda a;

	int opcion;

	do {

		opcion = menu();

		switch (opcion){

			case 1: //Insertar paciente

					menuInsertarPaciente(a);
					break;

			case 2: //Consultar paciente

					//menuBuscarPaciente(a);
					menuBuscarPaciente(a);

					break;

			case 3: //Listar pacientes
					menuListadoPacientes(a);
					break;

			case 4: //Copia de seguridad

					a.copiaSeguridad();
					break;

			case 5: //Restaurar copia de seguridad

					a.restaurarCopiaSeguridad();
					break;

			case 6: // Salir.
					cout<<"Hasta luego!"<<endl;
					break;

			default : //
					cout << "La opción elegida no es correcta!" << endl;
					break;

		}

	} while (opcion != 6);

	return 0;

}
