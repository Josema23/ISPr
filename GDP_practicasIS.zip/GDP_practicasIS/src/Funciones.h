/*
 * Agenda.h
 *
 *  Created on: 18/12/2014
 *      Author: i32goora
 */

#ifndef FUNCIONES_H_
#define FUNCIONES_H_

	#include "Agenda.h"
	#include "Contacto.h"

	using namespace consulta;

	//Funciones auxiliares.

	int menu();

	void mostrarContacto(Contacto c);

	void menuModificarPaciente(Agenda &a, Contacto &c);

	void menuBuscarPaciente(Agenda &a);

	void menuListadoPacientes(Agenda &a);

	bool menuInsertarPaciente(Agenda &a);

	bool comparacion(const Contacto &Primero,const Contacto &Segundo);


#endif /* FUNCIONES_H_ */
