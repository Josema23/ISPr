/*
 * Agenda.h
 *
 *  Created on: 03/12/2014
 *      Author: i32goora
 */

#ifndef AGENDA_H_
#define AGENDA_H_

#include <list>
#include <string>
#include "Contacto.h"

namespace consulta {

	class Agenda {

		public:
			Agenda();
			virtual ~Agenda();

			bool insertarPaciente(const Contacto &c);
			std::list<Contacto> buscarPaciente(std::string apellido);
			bool modificarPaciente(Contacto &c);
			bool borrarPaciente(std::string dni);

			//TODO: Esta función debe recibir el formato y nombre de fichero, para generar el listado.
			bool listadoPaciente();
			//

			bool restaurarCopiaSeguridad();
			bool copiaSeguridad();

		private:
			std::list<Contacto> listaContactos_;
			//bool comparacion (const Contacto &Primero,const Contacto &Segundo);
			void ordenarLista();
			void masFrecuentes(std::string dni);
			void escribirFichero (std::string fichero);

	};



} /* namespace consulta */
#endif /* AGENDA_H_ */
