/*
 * Contacto.cpp
 *
 *
 *  Created on: 18/12/2014
 *      Author: i32goora
 */
 
#include "iostream"
#include <cstdlib>
#include <list>


#include "Agenda.h"
#include "Contacto.h"
#include "Funciones.h"

using namespace std;
using namespace consulta;



int menu() {

	int opcion;

	//system("clear");

	cout << "\tMENU" << endl << endl;
	cout << "1. Insertar paciente" << endl;
	cout << "2. Consultar paciente" << endl;
	cout << "3. Listar pacientes" << endl;
	cout << "4. Copia de seguridad" << endl;
	cout << "5. Restaurar copia de seguridad" << endl;
	cout << "6. Salir" << endl << endl;
	cout << "Seleccione una opción: ";

	cin >> opcion;

	return opcion;
}



void mostrarContacto(Contacto c) {

	cout << "Apellidos y nombre....: " << c.getApellido() << ", " << c.getNombre() << "\n";
	cout << "DNI...................: " << c.getDni() << "\n";
	cout << "Telefono fijo.........: " << c.getTlfFijo() << "\n";
	cout << "Telefono movil........: " << c.getTlfMovil() << "\n";
	cout << "Direccion postal......: " << c.getDireccionpostal() << "\n";
	cout << "Email.................: " << c.getEmail() << "\n";
	cout << "Observaciones.........: " << c.getObservaciones() << "\n";
	cout << "Favorito..............: " << c.isFavorito() << "\n";
	cout << "Frecuencia............: " << c.getFrecuente() << "\n";
	cout << endl;

}

void menuModificarPaciente(Agenda &a, Contacto &c){

	int opcion;
	bool correcto=false;

	do {
		cout << "1. Modificar" << endl;
		cout << "2. Borrar" << endl;
		cout << "Introduzca la opcion...: ";
		cin >> opcion;
	} while (opcion != 1 && opcion != 2);

	if (opcion == 1) {

		correcto=a.borrarPaciente( c.getDni() );
/*
		if (correcto == true){
			cout << "Borrado" << endl;
		} else {
			cout << "No borrado" << endl;
		}
*/
		a.modificarPaciente(c);

		//a.listaContactos_.push_back(c);
		a.insertarPaciente(c);


	} else {

		correcto=a.borrarPaciente( c.getDni() );

		if (correcto == true){
			cout << "Borrado" << endl;
		} else {
			cout << "No borrado" << endl;
		}
	}

}

void menuBuscarPaciente(Agenda &a) {

	string apellido;
	string nombre;
	string dni;
	string modifica;
	string busqueda;
	list <Contacto> :: iterator it;
	list <Contacto> auxC;
	Contacto contAux;
	unsigned int tam;
	int salir=0;
	int controlador=0;

	do {
		cin.ignore();
		cout << "Seleccione el apellido...: "; //Introduce el apellido de la persona a buscar
		getline (cin, apellido);

		auxC=a.buscarPaciente(apellido); //Busca contactos con ese apellido y devuelve una lista
		tam=auxC.size();

		if (tam == 0){

			cout << "No se ha encontrado. ¿Quiere seguir buscando? (S/N)...: ";
			cin >> 	busqueda;

			if (busqueda=="N" || busqueda=="n"){
				salir=1;
			}
		}

	} while (tam == 0 && salir==0);

	if (salir==0){

		if (tam == 1){ //Si hay una sola persona

			contAux=auxC.front();

			mostrarContacto (contAux);



			//Pte. de corregir. Este método es privado.
			//a.masFrecuentes( contAux.getDni() );
			//


			cout << "Desea modificar el contacto? (S/N) "; // Indica si desea modicarlo
			cin >> modifica;

			if (modifica=="S" || modifica=="s"){
				a.modificarPaciente( contAux );
			}

		} else { //Hay mas de una persona con el mismo apellido

			for (it = auxC.begin() ; it != auxC.end() ; it++) {
					cout << (*it).getApellido() << ", " << (*it).getNombre();
					cout << endl;
			}

			cout << "Introduzca el nombre del paciente que quiere ver: ";//Introduce el nombre de la persona que busca
			cin >> nombre;

			for (it = auxC.begin() ; it != auxC.end() ; it++) {
				if ( nombre ==  (*it).getNombre() ) {
					contAux=(*it);
					controlador++;
				}
			}

			if (controlador > 1){

				cout << "Se han encontrado dos personas con el mismo nombre y apellidos." << endl;
				cout << "Introduzca el dni: ";//Introduce el nombre de la persona que busca
				cin >> dni;

				for (it = auxC.begin() ; it != auxC.end() ; it++) {
					if ( dni ==  (*it).getDni() ) {
						contAux=(*it);
					}
				}
			}


			mostrarContacto (contAux);


			//Pte. de corregir. Este método es privado.
			//a.masFrecuentes( contAux.getDni() );
			//

			cout << "Desea modificar el contacto? (S/N) "; // Indica si desea modicarlo
			cin >> modifica;

			if (modifica=="S" || modifica=="s"){
				a.modificarPaciente( contAux );
			}

		}

	}

}

void menuListadoPacientes(Agenda &a) {

	string formato;
	string nomFichero;
	string correcto;

	do {

		cout << "Cual es el formato...: ";
		cin >> formato;
		cout << "Esta correctamente escrito? (S/N)..: ";
		cin >> correcto;

	} while (correcto=="N" || correcto=="n");

	nomFichero= "Agenda."+formato;


	//a.ordenarLista(); --> se llama desde listadoPacietes()

	//TODO: Esta función debe recibir el formato y nombre de fichero, para generar el listado.
	a.listadoPaciente();

	//TODO: Pendiente de codificar.
	//a.escribirFichero(nomFichero);

}


bool menuInsertarPaciente(Agenda &a){

	std::string DNI;
	std::string nombre;
	std::string apellido;
	std::string tlf_fijo;
	std::string tlf_movil;
	std::string email;
	std::string direccionpostal;
	std::string observaciones;
	std::list<std::string> redessociales;
	bool favorito;
	int frecuente;

	std::string masRedes;
	std::string datosCorrectos;
	bool resultado;

	do{
		cout << "Introduzca los datos del paciente ..: \n";
		cout << "DNI .................: ";
		cin >> DNI;
		cout << "Nombre ..............: ";
		cin >> nombre;
		cout << "Apellidos ...........: ";
		cin >> apellido;
		cout << "Teléfono fijo .......: ";
		cin >> tlf_fijo;
		cout << "Teléfono móvil ......: ";
		cin >> tlf_movil;
		cout << "Correo electrónico ..: ";
		cin >> email;
		cout << "Dirección postal ....: ";
		cin >> direccionpostal;
		cout << "Observaciones .......: ";
		cin >> observaciones;

		cout << "¿ Están correctos los datos (S/N)?";
		cin >> datosCorrectos;


	}while(datosCorrectos!="S" && datosCorrectos!="s");

	do{

		std::string redSocial;

		cout << "Redes sociales ....: ";
		cin >> redSocial;

		redessociales.push_back(redSocial);

		cout << "¿ Desea introducir otra red más (S/N)? ";
		cin >> masRedes;

	}while(masRedes=="S" || masRedes=="s");

	favorito=false;
	frecuente=0;

	Contacto c(DNI,nombre,apellido,tlf_fijo,tlf_movil,email,direccionpostal,observaciones,redessociales,favorito,frecuente);

	resultado=a.insertarPaciente(c);

	return resultado;

}



bool comparacion (const Contacto &Primero,const Contacto &Segundo) {

	if ( ( Primero.getApellido() ).compare( Segundo.getApellido() ) < 0 ){
		return true;
	} else{
		return false;
	}

}

